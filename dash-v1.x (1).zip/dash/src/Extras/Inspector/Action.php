<?php
namespace Dash\Extras\Inspector;

abstract class Action {

	public static function options() {
		return [];
	}
}