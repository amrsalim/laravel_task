<?php
return [
	'users' => 'Users',
	'admin_groups' => 'Admin Groups',
	'admin_group_roles' => 'Admin Group Roles',
];