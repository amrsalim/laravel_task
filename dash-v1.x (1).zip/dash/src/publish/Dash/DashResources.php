<?php
return [
    // Users Start //
     \App\Dash\Resources\AdminGroupRoles::class,
     \App\Dash\Resources\AdminGroups::class,
     \App\Dash\Resources\Admins::class,
     \App\Dash\Resources\Users::class,
    // Users End//
];
